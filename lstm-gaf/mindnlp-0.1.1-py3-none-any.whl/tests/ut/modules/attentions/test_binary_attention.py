# Copyright 2022 Huawei Technologies Co., Ltd
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ============================================================================
"""Test Binary Attention"""

import unittest
import numpy as np

import mindspore
from mindspore import ops

from mindspore import context
from mindspore import Tensor

from mindnlp.modules import BinaryAttention


class TestBinaryAttention(unittest.TestCase):
    r"""
    Test module Binary Attention
    """

    def setUp(self):
        """
        Set up.
        """
        self.input = None

    def test_binary_attention_pynative(self):
        """
        unit test for binary attention with pynative mode.
        """
        context.set_context(mode=context.PYNATIVE_MODE)
        net = BinaryAttention()
        standard_normal = ops.StandardNormal(seed=114514)
        tensor_x = standard_normal((2, 30, 512))
        tensor_y = standard_normal((2, 20, 512))
        x_mask = Tensor(np.zeros_like(tensor_x.shape[:-1]), mindspore.float32)
        y_mask = Tensor(np.zeros_like(tensor_y.shape[:-1]), mindspore.float32)
        output_x, output_y = net(tensor_x, x_mask, tensor_y, y_mask)

        assert output_x.shape == tensor_x.shape
        assert output_y.shape == tensor_y.shape

    def test_binary_attention_graph(self):
        """
        unit test for binary attention whit graph mode.
        """

        context.set_context(mode=context.GRAPH_MODE)
        net = BinaryAttention()
        standard_normal = ops.StandardNormal(seed=114514)
        tensor_x = standard_normal((2, 30, 512))
        tensor_y = standard_normal((2, 20, 512))
        x_mask = Tensor(np.zeros_like(tensor_x.shape[:-1]), mindspore.float32)
        y_mask = Tensor(np.zeros_like(tensor_y.shape[:-1]), mindspore.float32)
        output_x, output_y = net(tensor_x, x_mask, tensor_y, y_mask)

        assert output_x.shape == tensor_x.shape
        assert output_y.shape == tensor_y.shape
